//
//  GamePlayLayer.m
//  Asteroid Chase
//
//  Created by Sohan on 3/5/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import "GamePlayLayer.h"
#import "SpaceShip.h"
#import "BulletsManager.h"
#import "EnemyManager.h"
#import "BlastManager.h"
#import "HudLayer.h"

#import "tinyxml.h"





@interface GamePlayLayer(PrivateMethods)

- (void) initWithNewGame;
- (void) addEnemies;
@end




@implementation GamePlayLayer

@synthesize spaceShipsCount = _spaceShipsCount;
@synthesize currentScore = _currentScore;

-(id)initWithScene:(GameScene*)gameScene
{
    if (self = [super init]){
        _gameScene = gameScene;
        
        [self initWithNewGame];
        
    }
    
    return self;
}


#pragma mark dealloc

- (void) dealloc
{
    [[SpaceShip sharedSpaceShip] release];
    [[BulletsManager sharedBulletsManager] release];
    [[EnemyManager sharedEnemyManager] release];
    [[BlastManager sharedBlastManager] release];

    [self unscheduleAllSelectors];
    [super dealloc];
}

- (void) onEnter{
    
    [super onEnter];
}

- (void) onExit{
    
    [super onExit];
}



#pragma mark draw

- (void) draw{
 
    [super draw];
	
	ccGLEnableVertexAttribs( kCCVertexAttribFlag_Position );
	
	kmGLPushMatrix();
    

    for(int i=0 ;i<_spaceShipsCount;i++){
        CGPoint ShipDrawPos = CGPointMake(160 + (i*20),730);

        ShipDrawPos.x += (i*15);
        
        CGPoint vertices[]={
            ccpAdd(ShipDrawPos,CGPointMake(0,10)),
            ccpAdd(ShipDrawPos,CGPointMake(10,0)),
            ccpAdd(ShipDrawPos,CGPointMake(10,-20)),
            ccpAdd(ShipDrawPos,CGPointMake(-10,-20)),
            ccpAdd(ShipDrawPos,CGPointMake(-10,0)),

        };
        
        ccColor4F color = {1.0f,1.0f,1.0f,1.0f};
        ccDrawSolidPoly(vertices,5,color);
        
    }
	
    [[PhysicsHelper sharedPhysicsHelper] onRenderFrame];
    [_spaceShip draw];
	
	kmGLPopMatrix();

}

#pragma mark NewGame

- (void) initWithNewGame{
    
    self.currentScore = 0;
    self.spaceShipsCount = 3;
    
    _levelNum = 1;

    [self loadModels];
  
    [self parseLevelInfo];

    [self addEnemies];
    [self scheduleUpdate];
}



- (void) addEnemies{
    
    CGPoint currentSpaceShipPos = ((SpaceShip*)[SpaceShip sharedSpaceShip]).currentSpaceShipPos;
    
                                                                    //  minimum distance from spaceship
    for(int i=0;i<_enemiesCount;i++)
    {
    EnemyParams *enemyParams = [[EnemyParams alloc] init];
    enemyParams.enemySpeed = RANDOM_NUMBER_IN_RANGE(1, 5);
    enemyParams.enemyAngle = RANDOM_NUMBER_IN_RANGE(LOWER_ANGLE_RANGE,HIGHER_ANGLE_RANGE);
        enemyParams.shapeNumber = RANDOM_NUMBER_IN_RANGE(0,NUM_OF_AVAILABLE_SHAPES);

    
        
        float xDistance = RANDOM_NUMBER_IN_RANGE(MIN_OFF_FROM_SHIP, (SCREEN_WIDTH - (MIN_OFF_FROM_SHIP *2 )));
        float yDistance = RANDOM_NUMBER_IN_RANGE(MIN_OFF_FROM_SHIP, (SCREEN_HEIGHT - (MIN_OFF_FROM_SHIP *2 )));

        enemyParams.enemyPosition = CGPointMake(currentSpaceShipPos.x + xDistance,currentSpaceShipPos.y + yDistance);
        
        if(enemyParams.enemyPosition.x>SCREEN_WIDTH){                               //Determine weather enemy has reated out of view area,if so then
                                                                                    //reset it
            enemyParams.enemyPosition = CGPointMake(enemyParams.enemyPosition.x - SCREEN_WIDTH, enemyParams.enemyPosition.y);
        }
        
        if(enemyParams.enemyPosition.y>SCREEN_HEIGHT){
            enemyParams.enemyPosition = CGPointMake(enemyParams.enemyPosition.x, enemyParams.enemyPosition.y - SCREEN_HEIGHT);
        }
        
          
            
        [[EnemyManager sharedEnemyManager] CreateEnemy:enemyParams:ENEMY_TYPE_ASTROID];
    }
}

-(void) update: (ccTime) dt
{
	[[PhysicsHelper sharedPhysicsHelper] onUpdateFrame:dt];
    [_spaceShip update:dt];
    [[BulletsManager sharedBulletsManager] update:dt];
    [[EnemyManager sharedEnemyManager] update:dt];
    [[BlastManager sharedBlastManager] update:dt];
}


#pragma mark loadModels

- (void) loadModels{
    
    _spaceShip = [SpaceShip sharedSpaceShip];
    _spaceShip.gamePlayLayer = self;
    
    
    [_spaceShip setFireDelegate:[BulletsManager sharedBulletsManager]];
    [_spaceShip setBlastDelegate:[BlastManager sharedBlastManager]];
    
    
    EnemyManager *_enemyManager = [EnemyManager sharedEnemyManager];
    _enemyManager.gamePlayLayer = self;
    
    [_enemyManager setFireDelegate:[BulletsManager sharedBulletsManager]];
    [_enemyManager setBlastDelegate:[BlastManager sharedBlastManager]];

}

#pragma mark destroyModels  
- (void) destroyAllModels{
    
    [[SpaceShip sharedSpaceShip] release];
    [[EnemyManager sharedEnemyManager] release];
    [[BulletsManager sharedBulletsManager] release];
    [[BlastManager sharedBlastManager] release];
}

#pragma mark RestartGame
- (void) onRestart{
    
    [self destroyAllModels];
    
    [self unscheduleAllSelectors];

    [self initWithNewGame];
    
    [_gameScene.hudLayer resetMenu];
}

#pragma mark RespawnSpaceShip
- (void) respawnSpaceShip{
    
    [_spaceShip release];
    _spaceShip = NULL;
    
    
    _spaceShipsCount--;
    
    if(_spaceShipsCount <= 0){
        
        [_gameScene.hudLayer setGameOverPopUp];
        return;
    }

    [self runAction:[CCSequence actions:[CCDelayTime actionWithDuration:1.5f],
                     [CCCallFunc actionWithTarget:self selector:@selector(scheduleRespawn:)],
                     nil]];
}

- (void)scheduleRespawn:(id)sender{

    [self unschedule:@selector(scheduleRespawn:)];
    if([[PhysicsHelper sharedPhysicsHelper] isObstacleSurrounding:100 :CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2)])
    {
        [self runAction:[CCSequence actions:[CCDelayTime actionWithDuration:0.2f],
                         [CCCallFunc actionWithTarget:self selector:@selector(scheduleRespawn:)],
                         nil]];
        return;
    }
    
    _spaceShip = [SpaceShip sharedSpaceShip];
    _spaceShip.gamePlayLayer = self;
    
    [_spaceShip setFireDelegate:[BulletsManager sharedBulletsManager]];
    [_spaceShip setBlastDelegate:[BlastManager sharedBlastManager]];
}


#pragma mark LevelComplete
- (void) onLevelComplete{
    
    if(!_spaceShip)
        return;
    
    if(_levelNum < _maxLevels){
        _levelNum ++;
    }

    [self destroyAllModels];
    [self loadModels];

    [self parseLevelInfo];
    [self addEnemies];
}


#pragma mark SpaceShip Controls


- (void) onActiveThrottle{
    [_spaceShip setThrottleSpaceShip:YES];
}

- (void) onDeactiveThrottle{
    [_spaceShip setThrottleSpaceShip:NO];
}

- (void) onActiveAnticlockwiseRot{
    [_spaceShip setSpaceShipRotationDirection:DIRECTION_ANTICLOCKWISE];
}

- (void) onDeactiveAnticlockwiseRot{
    [_spaceShip setSpaceShipRotationDirection:DIRECTION_STABLE];
}

- (void) onActiveClockwiseRot{
    [_spaceShip setSpaceShipRotationDirection:DIRECTION_CLOCKWISE];
}

- (void) onDeactiveClockwiseRot{
    [_spaceShip setSpaceShipRotationDirection:DIRECTION_STABLE];
}

- (void) onActiveFire{
    [_spaceShip setFireSpaceShip:YES];
}

- (void) onDeactiveFire{
    [_spaceShip setFireSpaceShip:NO];
}


#pragma mark Score

- (void) addScore:(int)scoreValue{
    _currentScore += scoreValue;
    [_gameScene.hudLayer setScore:_currentScore];
}

#pragma mark parseLevelInfo
- (void) parseLevelInfo{
    
    TiXmlDocument * _xmlDocument =nil;
    
    NSString * _filePath = [[NSBundle mainBundle] pathForResource:@"LevelData" ofType:@"xml"];

     NSAssert([[NSFileManager defaultManager] fileExistsAtPath:_filePath], @"Level File Not Available");
    
    _xmlDocument = new TiXmlDocument([_filePath UTF8String]);
    
      
    if((_xmlDocument == NULL) || (_xmlDocument->LoadFile() == false)){
        NSLog(@"Error loading xml file : %s\n", _xmlDocument->ErrorDesc());
        return;
    }
    
    TiXmlElement* _rootElement = _xmlDocument->RootElement();
    
    if(_rootElement == NULL){
        printf("Data not availble\n");
        return;
    }
    TiXmlNode  * _rootNode = _rootElement->FirstChild();

    
    while (_rootNode){
        _maxLevels ++;
		
		TiXmlElement *_element = _rootNode->ToElement();
		
		std::string _strlevelnum = _element->Attribute("level");

        if(atoi(_strlevelnum.c_str()) == _levelNum){
            TiXmlNode * _infoNode=_rootNode->FirstChild();
            
            while (_infoNode) {
                
                TiXmlElement * _infoElement = _infoNode->ToElement();

                std ::string _infoType=_infoElement->Attribute("InfoType");
                
                
                if(strcmp(_infoType.c_str(), "defaultParams") == 0){
                    
                    std ::string _numOfEnemies = _infoElement->Attribute("numofAstroids");
                    _enemiesCount =  atoi(_numOfEnemies.c_str());
                }
                
                if(strcmp(_infoType.c_str(), "defaultParams") == 0){
                    
                    std ::string _numofSaucers = _infoElement->Attribute("numofSaucers");

                }

                _infoNode = _infoNode->NextSibling();
            }
        }
        
        _rootNode = _rootNode->NextSibling();

    }
    
}

@end
