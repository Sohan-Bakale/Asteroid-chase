//
//  GamePlayLayer.h
//  Asteroid Chase
//
//  Created by Sohan on 3/5/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BulletParams.h"
#import "PhysicsHelper.h"
#import "GameScene.h"
#import "SimpleAudioEngine.h"


#define SCREEN_WIDTH 1024
#define SCREEN_HEIGHT 768

#define INITIAL_SPACESHIPS 3
#define TOTAL_ENEMIES_ON_START 6


#define RANDOM_NUMBER_IN_RANGE(LOW,HIGH) LOW + arc4random() % (HIGH - LOW)


@class SpaceShip;


@protocol fireBulletDelegate<NSObject>
@required
- (void) fireBullet:(BulletParams*)bulletParams;
@end

@protocol BlastDelegate<NSObject>
@required
- (void) createBlast:(CGPoint)blastPos;
@end

@interface GamePlayLayer : CCLayer {
    
    GameScene *_gameScene;

    int _spaceShipsCount;
    int _enemiesCount;
    int _currentScore;
    int _levelNum;
    int _maxLevels;
    
    SpaceShip * _spaceShip;
}

-(id)initWithScene:(GameScene*)gameScene;
- (void) parseLevelInfo;
- (void) onRestart;
- (void) respawnSpaceShip;
- (void) onLevelComplete;

- (void) loadModels;
- (void) destroyAllModels;

- (void) addScore:(int)scoreValue;

@property int spaceShipsCount;
@property int currentScore;


@end
