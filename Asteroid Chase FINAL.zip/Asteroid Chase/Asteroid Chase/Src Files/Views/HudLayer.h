//
//  HudLayer.h
//  Asteroid Chase
//
//  Created by Sohan on 3/7/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "ControlMenu.h"
#import "ControlMenuItem.h"

@class GameScene;
enum{
    
    PAUSE_POP_UP=0,
    GAME_OVER_POP_UP,
};

enum{
    SCORE_TAG = 0,
};

@interface HudLayer : CCLayer {
    CCMenu *_inGameMenu;
    GameScene *_gameScene;
    
    
    ControlMenu * _controlMenu;
    CCLabelTTF * _throttleLabel;
    CCLabelTTF * _clockWiseRotateLabel;
    CCLabelTTF * _antiClockWiseRotateLabel;
    CCLabelTTF * _fireLabel;
}

- (id)initWithScene:(GameScene*)gameScene;
- (void) setGameOverPopUp;
- (void) resetMenu;
- (void) setScore:(int)score;

@end
