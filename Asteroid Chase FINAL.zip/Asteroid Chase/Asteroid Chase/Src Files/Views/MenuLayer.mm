//
//  MenuLayer.m
//  Asteroid Chase
//
//  Created by Sohan on 3/5/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import "MenuLayer.h"
#import "GameScene.h"

@implementation MenuLayer

-(id)init{
    if(self = [super init])
    {
        _optionsMenu=nil;
        
        [self createOptionsMenu];
    }
    
    return self;
}

- (void) dealloc{
    
    if(_optionsMenu){
        [self removeChild:_optionsMenu cleanup:YES];
        _optionsMenu=NULL;
    }
    
    [super dealloc];

}

- (void) createOptionsMenu{
    
    if(_optionsMenu){
        [self removeChild:_optionsMenu cleanup:YES];
        _optionsMenu=NULL;
    }
    
    
    _optionsMenu = [CCMenu menuWithItems:nil];
    [self addChild:_optionsMenu z:1];
    [_optionsMenu setPosition:CGPointZero];
    
    CCLabelTTF * titleLabel= [CCLabelTTF labelWithString:@"Aestroids Chase" fontName:@"marker felt" fontSize:100];
    CCMenuItemLabel * titleLabelItem = [CCMenuItemLabel itemWithLabel:titleLabel];
    titleLabelItem.position = CGPointMake(512,584);
    [_optionsMenu addChild:titleLabelItem];
    
    
    CCLabelTTF * startLabel = [CCLabelTTF labelWithString:@"Start" fontName:@"marker felt" fontSize:70];
    
    CCMenuItemLabel * startLabelItem = [CCMenuItemLabel itemWithLabel:startLabel target:self selector:@selector(onStart:)];
    
    startLabelItem.position = CGPointMake(512,450);
    [_optionsMenu addChild:startLabelItem];
    
}

- (void) onStart : (id)sender
{
    [[CCDirector sharedDirector] replaceScene:[GameScene node]];
}

@end
