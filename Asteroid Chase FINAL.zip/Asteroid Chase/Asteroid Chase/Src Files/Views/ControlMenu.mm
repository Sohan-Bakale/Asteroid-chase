//
//  ControlMenu.m
//  Asteroid Chase
//
//  Created by Sohan on 3/10/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import "ControlMenu.h"
#import "ControlMenuItem.h"

@implementation ControlMenu

-(id)init{
    
    if(self = [super init]){
        
    }
    
    return self;
}


- (void) dealloc{
    
    [super dealloc];
}


- (void) onEnter{
    
    [super onEnter];
    
   }

- (void)registerWithTouchDispatcher{

    [[[CCDirector sharedDirector] touchDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:NO];
}

- (void) onExit{
    [super onExit];
}


-(void) addChild:(CCMenuItem*)child z:(NSInteger)z tag:(NSInteger) aTag
{
	NSAssert( [child isKindOfClass:[ControlMenuItem class]], @"Menu only supports MenuItem objects as children");
	[super addChild:child z:z tag:aTag];
}

-(CCMenuItemLabel *) itemForTouch: (UITouch *) touch
{
	CGPoint touchLocation = [touch locationInView: [touch view]];
	touchLocation = [[CCDirector sharedDirector] convertToGL: touchLocation];
    
    CGPoint prevLocation = [touch previousLocationInView:[touch view]];
    prevLocation = [[CCDirector sharedDirector] convertToGL: prevLocation];
    
	CCMenuItemLabel* item;
	CCARRAY_FOREACH(children_, item){
		// ignore invisible and disabled items: issue #779, #866
		if ( [item visible] && [item isEnabled] ) {
            
			CGPoint local = [item convertToNodeSpace:touchLocation];
			CGRect r = [item rect];
			r.origin = CGPointZero;
            
			if( CGRectContainsPoint( r, local ) )
				return item;
            else{
                local = [item convertToNodeSpace:prevLocation];

                if( CGRectContainsPoint(r,local)){
                [item unselected];
            }
            }
		}
	}
	return nil;
}


-(BOOL) ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{

	if( state_ != kCCMenuStateWaiting || !visible_ || ! enabled_)
		return NO;
    
	for( CCNode *c = self.parent; c != nil; c = c.parent )
		if( c.visible == NO )
			return NO;
    
	CCMenuItem *currentItem = [self itemForTouch:touch];
	[currentItem selected];
    


	return YES;
}

-(void) ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event
{
    
    CCMenuItem *currentItem = [self itemForTouch:touch];
	[currentItem unselected];
}

-(void) ccTouchCancelled:(UITouch *)touch withEvent:(UIEvent *)event
{
    
    CCMenuItem *currentItem = [self itemForTouch:touch];
	[currentItem unselected];
    
}

-(void) ccTouchMoved:(UITouch *)touch withEvent:(UIEvent *)event
{
    
	CCMenuItem *currentItem = [self itemForTouch:touch];
    
    if(![currentItem isSelected])
    [currentItem selected];
}


@end
