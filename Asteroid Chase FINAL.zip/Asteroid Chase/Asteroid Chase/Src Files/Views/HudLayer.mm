//
//  HudLayer.m
//  Asteroid Chase
//
//  Created by Sohan on 3/7/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import "HudLayer.h"
#import "MenuLayer.h"
#import "GameScene.h"
#import "GamePlayLayer.h"
#import "SpaceShip.h"

@interface HudLayer(PrivateMethods)

- (void) CreateInGameMenu;
- (void) addControls;
- (void) controlActivated:(CCLabelTTF*)label;
- (void) controlDectivated:(CCLabelTTF*)label;

@end

@implementation HudLayer



-(id)initWithScene:(GameScene*)gameScene
{
    if (self = [super init]){
        
        _gameScene = gameScene;

        [self CreateInGameMenu];
        [self addControls];

    }
    
    return self;
}

- (void) dealloc{
    
    if(_inGameMenu){
        [self removeChild:_inGameMenu cleanup:YES];
        _inGameMenu = NULL;
    }
    
    if(CCMenu * _pauseMenu = (CCMenu*)[self getChildByTag:PAUSE_POP_UP]){
        [self removeChild:_pauseMenu cleanup:YES];
        _pauseMenu = NULL;
    }
    
    
    if(CCMenu * _gameOverMenu = (CCMenu*)[self getChildByTag:GAME_OVER_POP_UP]){
        [self removeChild:_gameOverMenu cleanup:YES];
        _gameOverMenu = NULL;
    }

    if(_controlMenu){
    [self removeChild:_controlMenu cleanup:YES];
        _controlMenu = NULL;
    }

    [super dealloc];
}

- (void) onEnter{
    
    [super onEnter];
}

- (void) onExit{
    [super onExit];
}

- (void) CreateInGameMenu{
    
    
    if(_inGameMenu){
        [self removeChild:_inGameMenu cleanup:YES];
        _inGameMenu = NULL;
    }
    
    _inGameMenu = [CCMenu menuWithItems:nil];
    [self addChild:_inGameMenu];
    _inGameMenu.position=CGPointZero;
    
       
    CCMenuItemLabel * shipsCountLabel = [CCMenuItemLabel itemWithLabel:[CCLabelTTF labelWithString:@"Ships:" fontName:@"marker felt" fontSize:50]];
    shipsCountLabel.position = CGPointMake(70,730);
    [_inGameMenu addChild:shipsCountLabel];
    
    
       
    CCMenuItemLabel * scoreLabel = [CCMenuItemLabel itemWithLabel:[CCLabelTTF labelWithString:[NSString stringWithFormat:@"Score:%d",0] fontName:@"marker felt" fontSize:50]];
    scoreLabel.position = CGPointMake(400,730);
    [_inGameMenu addChild:scoreLabel z:1 tag:SCORE_TAG];
    
    
    
    CCMenuItemLabel * pauseLabel = [CCMenuItemLabel itemWithLabel:[CCLabelTTF labelWithString:@"Pause" fontName:@"marker felt" fontSize:50] target:self selector:@selector(onPause:)];
    pauseLabel.position = CGPointMake(700,730);
    [_inGameMenu addChild:pauseLabel];
    
    
    
    CCMenuItemLabel * restartLabel = [CCMenuItemLabel itemWithLabel:[CCLabelTTF labelWithString:@"Restart" fontName:@"marker felt" fontSize:50] target:self selector:@selector(onRestart:)];
    restartLabel.position = CGPointMake(900,730);
    [_inGameMenu addChild:restartLabel];
}

-(void) onPause : (id) sender{
    
    if([self getChildByTag:PAUSE_POP_UP]){
        return;
    }
    [_gameScene.gamePlayLayer pauseSchedulerAndActions];
    
    [_inGameMenu setTouchEnabled:NO];
    [_controlMenu setTouchEnabled:NO];
    
    CCMenu * pauseMenu = [CCMenu menuWithItems: nil];
    [self addChild:pauseMenu z:1 tag:PAUSE_POP_UP];
    pauseMenu.position = CGPointZero;
    
    CCMenuItemLabel * pausedLabel = [CCMenuItemLabel itemWithLabel:[CCLabelTTF labelWithString:@"Paused" fontName:@"marker felt" fontSize:60]];
    pausedLabel.position = CGPointMake(512,500);
    [pauseMenu addChild:pausedLabel];
    
    
    CCMenuItemLabel * resumeLabel = [CCMenuItemLabel itemWithLabel:[CCLabelTTF labelWithString:@"Resume" fontName:@"marker felt" fontSize:60] target:self selector:@selector(onResume:)];
    resumeLabel.position = CGPointMake(300,400);
    
    [pauseMenu addChild:resumeLabel];
    
    CCMenuItemLabel * restartLabel = [CCMenuItemLabel itemWithLabel:[CCLabelTTF labelWithString:@"Restart" fontName:@"marker felt" fontSize:50] target:self selector:@selector(onRestart:)];
    restartLabel.position = CGPointMake(512,400);
    [pauseMenu addChild:restartLabel];
    
    CCMenuItemLabel * menuLabel = [CCMenuItemLabel itemWithLabel:[CCLabelTTF labelWithString:@"Menu" fontName:@"marker felt" fontSize:50] target:self selector:@selector(onMenu:)];
    menuLabel.position = CGPointMake(700,400);
    [pauseMenu addChild:menuLabel];
    
}

- (void) setGameOverPopUp{
    [_inGameMenu setTouchEnabled:NO];
    [_controlMenu setTouchEnabled:NO];
    
    CCMenu * gameOverMenu = [CCMenu menuWithItems: nil];
    [self addChild:gameOverMenu z:1 tag:GAME_OVER_POP_UP];
    gameOverMenu.position = CGPointZero;
    
    CCMenuItemLabel * gameOverLabel = [CCMenuItemLabel itemWithLabel:[CCLabelTTF labelWithString:@"Game Over" fontName:@"marker felt" fontSize:60]];
    gameOverLabel.position = CGPointMake(512,500);
    [gameOverMenu addChild:gameOverLabel];
    
    
    CCMenuItemLabel * restartLabel = [CCMenuItemLabel itemWithLabel:[CCLabelTTF labelWithString:@"Restart" fontName:@"marker felt" fontSize:50] target:self selector:@selector(onRestart:)];
    restartLabel.position = CGPointMake(400,400);
    [gameOverMenu addChild:restartLabel];
    
    CCMenuItemLabel * menuLabel = [CCMenuItemLabel itemWithLabel:[CCLabelTTF labelWithString:@"Menu" fontName:@"marker felt" fontSize:50] target:self selector:@selector(onMenu:)];
    menuLabel.position = CGPointMake(600,400);
    [gameOverMenu addChild:menuLabel];

}

-(void) onResume : (id) sender{
    [_gameScene.gamePlayLayer resumeSchedulerAndActions];
    
    if(CCMenu *pauseMenu = (CCMenu*)[self getChildByTag:PAUSE_POP_UP]){
        [self removeChild:pauseMenu cleanup:YES];
        pauseMenu=NULL;
        
        [_inGameMenu setTouchEnabled:YES];
        [_controlMenu setTouchEnabled:YES];
        

    }
}

- (void) onRestart : (id) sender{
    
    if(CCMenu *pauseMenu = (CCMenu*)[self getChildByTag:PAUSE_POP_UP]){
        [self removeChild:pauseMenu cleanup:YES];
        pauseMenu=NULL;
    }
    
    if(CCMenu * _gameOverMenu = (CCMenu*)[self getChildByTag:GAME_OVER_POP_UP]){
        [self removeChild:_gameOverMenu cleanup:YES];
        _gameOverMenu = NULL;
    }


    [_gameScene.gamePlayLayer onRestart];
    [_inGameMenu setTouchEnabled:YES];
    [_controlMenu setTouchEnabled:YES];
}

- (void) onMenu : (id) sender{
    [[CCDirector sharedDirector] replaceScene:[MenuLayer node]];
}

- (void) resetMenu{
    [self CreateInGameMenu];
}


-(void) addControls{
    
    if(_controlMenu){
        [self removeChild:_controlMenu cleanup:YES];
        _controlMenu = NULL;
    }
    
      _controlMenu = [ControlMenu menuWithItems:nil];
    _controlMenu.position = CGPointZero;
    [self addChild:_controlMenu];

    ControlMenuItem * throttleItem = [ControlMenuItem itemWithLabel:[CCLabelTTF labelWithString:@"Throttle" fontName:@"marker felt" fontSize:50]];
    throttleItem.position = CGPointMake(900,50);
    [_controlMenu addChild:throttleItem];
    
    [throttleItem setTarget:_gameScene.gamePlayLayer];
    [throttleItem setActivateSelector:@selector(onActiveThrottle)];
    [throttleItem setDeactivateSelector:@selector(onDeactiveThrottle)];
    
    
    ControlMenuItem * fireItem = [ControlMenuItem itemWithLabel:[CCLabelTTF labelWithString:@"Fire" fontName:@"marker felt" fontSize:50]];
    fireItem.position = CGPointMake(900,150);
    [_controlMenu addChild:fireItem];
    
    [fireItem setTarget:_gameScene.gamePlayLayer];
    [fireItem setActivateSelector:@selector(onActiveFire)];
    [fireItem setDeactivateSelector:@selector(onDeactiveFire)];
    
    ControlMenuItem * anticlockwiseRotateItem = [ControlMenuItem itemWithLabel:[CCLabelTTF labelWithString:@"<-" fontName:@"marker felt" fontSize:70]];
    anticlockwiseRotateItem.position = CGPointMake(100,50);
    [_controlMenu addChild:anticlockwiseRotateItem];
    
    [anticlockwiseRotateItem setTarget:_gameScene.gamePlayLayer];
    [anticlockwiseRotateItem setActivateSelector:@selector(onActiveAnticlockwiseRot)];
    [anticlockwiseRotateItem setDeactivateSelector:@selector(onDeactiveAnticlockwiseRot)];
    
    ControlMenuItem * clockwiseRotateItem = [ControlMenuItem itemWithLabel:[CCLabelTTF labelWithString:@"->" fontName:@"marker felt" fontSize:70]];
    clockwiseRotateItem.position = CGPointMake(200,50);
    [_controlMenu addChild:clockwiseRotateItem];
    
    [clockwiseRotateItem setTarget:_gameScene.gamePlayLayer];
    [clockwiseRotateItem setActivateSelector:@selector(onActiveClockwiseRot)];
    [clockwiseRotateItem setDeactivateSelector:@selector(onDeactiveClockwiseRot)];
}




- (void) setScore:(int)score{
    CCMenuItemLabel * menuLabel = (CCMenuItemLabel*)[_inGameMenu getChildByTag:SCORE_TAG];
    [menuLabel.label setString:[NSString stringWithFormat:@"Score:%d",score]];
}


@end
