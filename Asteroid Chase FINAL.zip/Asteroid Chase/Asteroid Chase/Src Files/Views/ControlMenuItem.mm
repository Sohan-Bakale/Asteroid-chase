//
//  ControlMenuItem.m
//  Asteroid Chase
//
//  Created by Sohan on 3/10/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import "ControlMenuItem.h"


@implementation ControlMenuItem


+ (id) itemWithLabel:(CCNode<CCLabelProtocol,CCRGBAProtocol>*)label target:(id)target selector:(SEL)selector
{
	return [[[self alloc] initWithLabel:label target:target selector:selector] autorelease];
}

- (void) dealloc
{
	[super dealloc];
}

- (void) setTarget:(id)target{
    _target = target;
}

- (void) setActivateSelector:(SEL)selector{
    _activateSelector = selector;
}
- (void) setDeactivateSelector:(SEL)selector{
    _deactivateSelector  = selector;
}


-(void) selected{
    
    [self setTarget:_target selector:_activateSelector];
    [self activate];
    [super selected];
}

-(void) unselected
{
	
    [self setTarget:_target selector:_deactivateSelector];
    [self activate];

    [super unselected];
}


@end
