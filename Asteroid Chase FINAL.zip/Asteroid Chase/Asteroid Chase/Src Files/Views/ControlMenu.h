//
//  ControlMenu.h
//  Asteroid Chase
//
//  Created by Sohan on 3/10/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface ControlMenu : CCMenu {
    
}

@end
