//
//  ControlMenuItem.h
//  Asteroid Chase
//
//  Created by Sohan on 3/10/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface ControlMenuItem : CCMenuItemLabel {
    
    id _target;
    SEL _activateSelector;
    SEL _deactivateSelector;
}

- (void) setTarget:(id)target;
- (void) setActivateSelector:(SEL)selector;
- (void) setDeactivateSelector:(SEL)selector;

@end
