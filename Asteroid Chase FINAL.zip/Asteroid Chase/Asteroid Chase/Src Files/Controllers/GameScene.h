//
//  GameScene.h
//  Asteroid Chase
//
//  Created by Sohan on 3/5/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@class GamePlayLayer;
@class HudLayer;


@interface GameScene : CCScene {
    GamePlayLayer *_gamePlayLayer;    //Here we load all our models and simulate
    HudLayer      *_hudLayer;         //Here we display the game play menu to the user
}



@property (nonatomic,assign) GamePlayLayer *gamePlayLayer;
@property (nonatomic,assign) HudLayer *hudLayer;

@end
