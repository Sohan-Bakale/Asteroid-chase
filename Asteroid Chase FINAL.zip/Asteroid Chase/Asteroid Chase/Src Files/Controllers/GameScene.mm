//
//  GameScene.m
//  Asteroid Chase
//
//  Created by Sohan on 3/5/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import "GameScene.h"

#import "GamePlayLayer.h"
#import "MenuLayer.h"
#import "HudLayer.h"

@interface GameScene(PrivateMethods)
- (void) createGamePlayLayer;
- (void) createHudLayer;

@end

@implementation GameScene

@synthesize gamePlayLayer = _gamePlayLayer;
@synthesize hudLayer = _hudLayer;


-(id) init {
    if(self=[super init])
    {
        self.gamePlayLayer = NULL;
        [self createGamePlayLayer];
        [self createHudLayer];
        
    }
    
    return self;
}

#pragma mark GamePlayLayer

- (void) createGamePlayLayer{
    self.gamePlayLayer = [[[GamePlayLayer alloc] initWithScene:self] autorelease];
    [self addChild:self.gamePlayLayer z:1];
}


#pragma mark HudLayer      

- (void) createHudLayer{
    self.hudLayer = [[[HudLayer alloc] initWithScene:self] autorelease];
    [self addChild:self.hudLayer z:1];
}



-(void) dealloc {
        
   
    if(self.gamePlayLayer)
    {
        [self.gamePlayLayer unscheduleAllSelectors];
        [self removeChild:self.gamePlayLayer cleanup:YES];
        self.gamePlayLayer = NULL;
    }
    
    
    if(self.hudLayer)
    {
        [self.hudLayer unscheduleAllSelectors];
        [self removeChild:self.hudLayer cleanup:YES];
        self.hudLayer = NULL;
    }

    
    [super dealloc];
 }

@end
