//
//  BulletsConstants.h
//  Asteroid Chase
//
//  Created by Sohan on 3/8/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import <Foundation/Foundation.h>

#define BULLETS_CREATION_INTERVAL 0.2f

