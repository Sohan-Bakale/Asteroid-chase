//
//  Bullet.h
//  Asteroid Chase
//
//  Created by Sohan on 3/8/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BulletsManager.h"

@interface Bullet : NSObject {
    
    BulletParams *_bulletParams;
    PhysicsBody * _bulletBody;
    
    BOOL _destroyBullet;
    float _bulletLife;

}

@property BOOL destroyBullet;

- (id) initWithParams:(BulletParams*)bulletParams;
- (void) fireBullet;
- (void) update : (ccTime) dt;

@end
