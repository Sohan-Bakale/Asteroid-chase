//
//  Bullet.m
//  Asteroid Chase
//
//  Created by Sohan on 3/8/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import "Bullet.h"


@implementation Bullet

@synthesize destroyBullet = _destroyBullet;

- (id) initWithParams:(BulletParams*)bulletParams{
    if(self = [super init])
    {
        _bulletBody = NULL;
        _bulletParams = bulletParams;
        _bulletLife = 0.0f;
        [self fireBullet];
    }
    
    return self;
}


-(void) dealloc{
    
    [[PhysicsHelper sharedPhysicsHelper] destroyBody:_bulletBody];
    
    [_bulletParams release];
    _bulletParams = NULL;
    
    [super dealloc];
}


- (void) update : (ccTime) dt{
        
    _bulletLife += dt;

    if(_bulletLife >= _bulletParams.bulletLife){
        self.destroyBullet = TRUE;
    }
    
    
    
    
    CGPoint Pos=[[PhysicsHelper sharedPhysicsHelper] getPositionOfBody:_bulletBody];
    
    if(Pos.x < 0){
        [[PhysicsHelper sharedPhysicsHelper] setPositionOfBody:_bulletBody :CGPointMake((Pos.x+1024.0f),Pos.y)];
    }
    
    if(Pos.x > 1024){
        [[PhysicsHelper sharedPhysicsHelper] setPositionOfBody:_bulletBody :CGPointMake((Pos.x-1024.0f),Pos.y)];
    }
    
    if(Pos.y < 0){
        [[PhysicsHelper sharedPhysicsHelper] setPositionOfBody:_bulletBody :CGPointMake(Pos.x,(Pos.y+768.0f))];
    }
    
    if(Pos.y > 768){
        [[PhysicsHelper sharedPhysicsHelper] setPositionOfBody:_bulletBody :CGPointMake(Pos.x,(Pos.y-768.0f))];
    }

}


- (void) fireBullet{
    _bulletBody = [[PhysicsHelper sharedPhysicsHelper] createBody:_bulletParams.bulletPosition :BODY_TYPE_DYNAMIC];
    
    physicsParams *_physicsParams = [[physicsParams alloc] init];
    [[PhysicsHelper sharedPhysicsHelper] AddCircleShapeToBody:_bulletBody:_bulletParams.bulletSize :CGPointZero:self:_physicsParams];
    
    float bulletAngle = _bulletParams.bulletAngle;
    float bulletSpeed = _bulletParams.bulletSpeed;
    
    [[PhysicsHelper sharedPhysicsHelper] setLinearVelocityOfBody:_bulletBody:CGPointMake(-bulletSpeed*cos(bulletAngle), -bulletSpeed*sin(bulletAngle))];
}

@end
