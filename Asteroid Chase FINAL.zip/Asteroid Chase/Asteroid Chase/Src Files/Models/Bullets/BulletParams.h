//
//  BulletParams.h
//  Asteroid Chase
//
//  Created by Sohan on 3/8/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface BulletParams : NSObject {
    
    CGPoint _bulletPosition;
    float _bulletAngle;
    float _bulletSpeed;
    float _bulletSize;
    float _bulletLife;
}

@property CGPoint bulletPosition;
@property float bulletAngle;
@property float bulletSpeed;
@property float bulletSize;
@property float bulletLife;

@end
