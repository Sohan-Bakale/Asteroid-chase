//
//  BulletParams.m
//  Asteroid Chase
//
//  Created by Sohan on 3/8/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import "BulletParams.h"


@implementation BulletParams

@synthesize bulletPosition = _bulletPosition;
@synthesize bulletAngle = _bulletAngle;
@synthesize bulletSpeed = _bulletSpeed;
@synthesize bulletSize = _bulletSize;
@synthesize bulletLife = _bulletLife;

-(id)init{
    if(self = [super init]){
        self.bulletPosition = CGPointZero;
        self.bulletAngle = 0.0f;
        self.bulletSpeed = 5.0f;
        self.bulletSize = 5.0f;
        self.bulletLife = 5.0f;
    }
    
    return self;
}

- (void) dealloc{
    
    [super dealloc];
}

@end
