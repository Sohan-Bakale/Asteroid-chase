//
//  BulletsManager.m
//  Asteroid Chase
//
//  Created by Sohan on 3/8/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import "BulletsManager.h"
#import "Bullet.h"

@implementation BulletsManager

@synthesize gamePlayLayer=_gamePlayLayer;

BulletsManager *_bulletsManager = NULL;


+ (id) sharedBulletsManager{
    
    if(_bulletsManager == NULL){
        return (_bulletsManager=[[self alloc] init]);
    }
    
    return _bulletsManager;
}

- (id) init{
    
    if(self = [super init]){
        _bulletArray = [[NSMutableArray alloc] init];
    }
    
    return self;
}

- (void) dealloc{
    
    if(_bulletArray){
        [_bulletArray removeAllObjects];
        [_bulletArray release];
        _bulletArray = NULL;
    }
    
    _bulletsManager = NULL;
    [super dealloc];
}

- (void) fireBullet:(BulletParams *)bulletParams{
    Bullet * _bullet = [[Bullet alloc] initWithParams:bulletParams];
    [_bulletArray addObject:_bullet];
    [_bullet release];
    
    [[SimpleAudioEngine sharedEngine] playEffect:@"Sounds/Shoot.wav"];
}


- (void) update : (ccTime) dt{
    
    for (int i=0;i<[_bulletArray count];i++) {
        
        Bullet * _bullet = [_bulletArray objectAtIndex:i];
        
        [_bullet update:dt];
        
        
        if(_bullet.destroyBullet){
            [_bulletArray removeObject:_bullet];
            --i;
            continue;
        }
    }
    
}

@end
