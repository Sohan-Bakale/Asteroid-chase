//
//  BulletsManager.h
//  Asteroid Chase
//
//  Created by Sohan on 3/8/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BulletsConstants.h"
#import "BulletParams.h"
#import "GamePlayLayer.h"


@interface BulletsManager : NSObject<fireBulletDelegate> {
    GamePlayLayer * _gamePlayLayer;
    NSMutableArray * _bulletArray;
}

@property (nonatomic,assign) GamePlayLayer *gamePlayLayer;

+ (id) sharedBulletsManager;
- (void) update : (ccTime) dt;


@end
