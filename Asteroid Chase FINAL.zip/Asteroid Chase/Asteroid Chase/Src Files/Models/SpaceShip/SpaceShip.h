//
//  SpaceShip.h
//  Asteroid Chase
//
//  Created by Sohan on 3/6/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

#import "GamePlayLayer.h"
#import "BulletParams.h"
#import "SpaceShipConstants.h"

@interface SpaceShip : NSObject {
    
    GamePlayLayer * _gamePlayLayer;

    BOOL  _toThrust;
    float _angle;
    BOOL _isFiring;
    CGPoint _currentSpaceShipPos;
    float _currentSpaceShipAngle;
    BOOL _toDestroySpaceShip;
    
    PhysicsBody * _spaceShipBody;
    
    eRotationDirection _rotationDirection;
    
    id<fireBulletDelegate> _fireDelegate;
    id<BlastDelegate> _blastDelegate;

}

@property (nonatomic,assign) GamePlayLayer *gamePlayLayer;
@property (readwrite) CGPoint currentSpaceShipPos;
@property (readwrite) float currentSpaceShipAngle;
@property (readwrite) BOOL toThrust;
@property (readwrite) eRotationDirection rotationDirection;
@property (readwrite) BOOL isFiring;
@property (readwrite) BOOL toDestroySpaceShip;

+ (id) sharedSpaceShip;
- (void) setFireDelegate:(id<fireBulletDelegate>)firedelegate;
- (void) setBlastDelegate:(id<BlastDelegate>)blastdelegate;
- (void) createSpaceShipBody;
- (void) update:(ccTime) dt;
- (void)draw;
- (void) setThrottleSpaceShip:(BOOL)toThrust;
- (void) setFireSpaceShip:(BOOL)_firing;
- (void) setSpaceShipRotationDirection:(eRotationDirection)rotationDirection;

@end
