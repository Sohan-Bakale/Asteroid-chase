//
//  SpaceShip.m
//  Asteroid Chase
//
//  Created by Sohan on 3/6/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import "SpaceShip.h"

@implementation SpaceShip

SpaceShip *_sharedSpaceShip = NULL;
@synthesize toDestroySpaceShip = _toDestroySpaceShip;

@synthesize gamePlayLayer=_gamePlayLayer;

@synthesize currentSpaceShipPos = _currentSpaceShipPos;
@synthesize currentSpaceShipAngle = _currentSpaceShipAngle;
@synthesize toThrust = _toThrust;
@synthesize rotationDirection = _rotationDirection;
@synthesize isFiring = _isFiring;

+ (id) sharedSpaceShip{
    
    if(_sharedSpaceShip == NULL){
        return (_sharedSpaceShip=[[self alloc] init]);
    }
    
    return _sharedSpaceShip;
}


-(id)init {
    if(self = [super init])
    {
        _fireDelegate = NULL;
        _blastDelegate = NULL;
        self.toThrust = NO;
        self.currentSpaceShipAngle = 0.0f;
        self.isFiring = NO;
        self.currentSpaceShipPos = CGPointMake(512,384);
        self.currentSpaceShipAngle = -M_PI_2;
        self.toDestroySpaceShip = NO;
        
        _spaceShipBody = NULL;
        [self createspaceShipBody];
    }
    
    return self;
}


-(void) dealloc{
    
    [[PhysicsHelper sharedPhysicsHelper] destroyBody:_spaceShipBody];
    _sharedSpaceShip = NULL;
    [super dealloc];
}

- (void) setFireDelegate:(id<fireBulletDelegate>)firedelegate{
        _fireDelegate = firedelegate;
}

- (void) setBlastDelegate:(id<BlastDelegate>)blastdelegate{
    _blastDelegate = blastdelegate;
}

- (void) setThrottleSpaceShip:(BOOL)toThrust{
    _toThrust = toThrust;
}

- (void) setFireSpaceShip:(BOOL)_firing{
    _isFiring = _firing;
}

- (void) setSpaceShipRotationDirection:(eRotationDirection)rotationDirection{
    _rotationDirection = rotationDirection;
}

- (void) update : (ccTime) dt{
    
    _currentSpaceShipAngle = [[PhysicsHelper sharedPhysicsHelper] getAngleOfBody:_spaceShipBody];

    if(_toThrust){
        [[PhysicsHelper sharedPhysicsHelper] setLinearVelocityOfBody:_spaceShipBody :CGPointMake(-SPACESHIP_VEL*cos(_currentSpaceShipAngle),-SPACESHIP_VEL*sin(_currentSpaceShipAngle))];
    }
    else{
        CGPoint vel = [[PhysicsHelper sharedPhysicsHelper] getLinearVelocityOfBody:_spaceShipBody];
                
        if(ccpLength(vel))
            [[PhysicsHelper sharedPhysicsHelper] setLinearVelocityOfBody:_spaceShipBody :ccpMult(vel,0.97f)];

    }
    
    static float currentElapsedTime= 0.0f;

    if(_isFiring){
        if(currentElapsedTime == 0.0f){
        BulletParams * bulletParams = [[BulletParams alloc] init];
        bulletParams.bulletAngle = _currentSpaceShipAngle;
            bulletParams.bulletSpeed = 15.0f;
        
        CGPoint bodyPos = [[PhysicsHelper sharedPhysicsHelper] getPositionOfBody:_spaceShipBody];
        float bulRelOffFromCenter = 60.0f;
        
        bulletParams.bulletPosition = CGPointMake(bodyPos.x-(bulRelOffFromCenter*cos(bulletParams.bulletAngle)),bodyPos.y-(bulRelOffFromCenter*sin(bulletParams.bulletAngle)));
        
        bulletParams.bulletLife = 1.0f;
        
        [_fireDelegate fireBullet:bulletParams];
        }
        
        currentElapsedTime +=dt;
        if(currentElapsedTime >= BULLET_FIRE_INTERVAL)
            currentElapsedTime = 0.0f;
    }
    else{
        currentElapsedTime = 0.0f;
    }
               
            
      
    switch (_rotationDirection) {
        case DIRECTION_STABLE:{
            
            if([[PhysicsHelper sharedPhysicsHelper] getAngularVelocityOfBody:_spaceShipBody])
                [[PhysicsHelper sharedPhysicsHelper] setAngularVelocityOfBody:_spaceShipBody :0];
            }
            
            break;
            
        case DIRECTION_ANTICLOCKWISE:{
            [[PhysicsHelper sharedPhysicsHelper] setAngularVelocityOfBody:_spaceShipBody :SPACESHIP_ANG_VEL];            
        }
            break;
            
        case DIRECTION_CLOCKWISE:{
            [[PhysicsHelper sharedPhysicsHelper] setAngularVelocityOfBody:_spaceShipBody :-SPACESHIP_ANG_VEL];
        }
            break;
            
        default:
            break;
    }
    
    
    if(_toDestroySpaceShip){
        [_blastDelegate createBlast:_currentSpaceShipPos];
        [[SimpleAudioEngine sharedEngine] playEffect:@"Sounds/Blast.wav"];
        [_gamePlayLayer respawnSpaceShip];
        return;
    }
    
    
    _currentSpaceShipPos=[[PhysicsHelper sharedPhysicsHelper] getPositionOfBody:_spaceShipBody];
    
    BoundingBox  boundingBox = [[PhysicsHelper sharedPhysicsHelper] getBoundingBoxOfBody:_spaceShipBody];
    
    CGPoint lowerBound = boundingBox.lowerBound;
    CGPoint upperBound = boundingBox.upperBound;
    
    if(lowerBound.x < 0 && upperBound.x < 0){
        [[PhysicsHelper sharedPhysicsHelper] setPositionOfBody:_spaceShipBody :CGPointMake(SCREEN_WIDTH + _currentSpaceShipPos.x - lowerBound.x,_currentSpaceShipPos.y)];
    }
    
    if(lowerBound.x > SCREEN_WIDTH  && upperBound.x >SCREEN_WIDTH){
        [[PhysicsHelper sharedPhysicsHelper] setPositionOfBody:_spaceShipBody :CGPointMake( _currentSpaceShipPos.x - upperBound.x,_currentSpaceShipPos.y)];
    }
    
    if(lowerBound.y < 0 && upperBound.y <0){
        [[PhysicsHelper sharedPhysicsHelper] setPositionOfBody:_spaceShipBody :CGPointMake(_currentSpaceShipPos.x, SCREEN_HEIGHT + _currentSpaceShipPos.y - lowerBound.y)];
    }
    
    if(lowerBound.y > SCREEN_HEIGHT && upperBound.y >SCREEN_HEIGHT){
        [[PhysicsHelper sharedPhysicsHelper] setPositionOfBody:_spaceShipBody :CGPointMake(_currentSpaceShipPos.x,_currentSpaceShipPos.y - upperBound.y)];
    }

}

- (void)draw{
    
    static int framesCount = 0;
    
    if(_toThrust){
        
        if(framesCount == 0){
            
            CGPoint startPos = CGPointMake(_currentSpaceShipPos.x+(32*cos(_currentSpaceShipAngle)), _currentSpaceShipPos.y+(32*sin(_currentSpaceShipAngle)));
            
            float endPointAngle = _currentSpaceShipAngle + CC_DEGREES_TO_RADIANS(35.0f);
            
            CGPoint endPos = CGPointMake(startPos.x+(30*cos(endPointAngle)), startPos.y+(30*sin(endPointAngle)));
            
            ccDrawLine(startPos,endPos);
            
            endPointAngle = _currentSpaceShipAngle - CC_DEGREES_TO_RADIANS(35.0f);
            endPos = CGPointMake(startPos.x+(30*cos(endPointAngle)), startPos.y+(30*sin(endPointAngle)));

            ccDrawLine(startPos,endPos);
            
            endPointAngle = _currentSpaceShipAngle - CC_DEGREES_TO_RADIANS(0.0f);
            endPos = CGPointMake(startPos.x+(23*cos(endPointAngle)), startPos.y+(23*sin(endPointAngle)));
            
            
            ccDrawLine(startPos,endPos);

        }
        
        (++framesCount==6)?framesCount = 0:YES;
    }
    else{
        framesCount =0;
    }
    
}

- (void) createspaceShipBody{
    _spaceShipBody = [[PhysicsHelper sharedPhysicsHelper] createBody:_currentSpaceShipPos :BODY_TYPE_DYNAMIC];
    
    
    physicsParams *_physicsParams = [[physicsParams alloc] init];
    [[PhysicsHelper sharedPhysicsHelper] AddBoxShapeToBody:_spaceShipBody :30.0f :20.0f:CGPointZero:0 :self:_physicsParams];
    
    CGPoint * Points = new CGPoint[3];
    
    Points[0]=CGPointMake(-50,0);
    Points[1]=CGPointMake(-30,-20);
    Points[2]=CGPointMake(-30,20);
    
    _physicsParams = [[physicsParams alloc] init];
    [[PhysicsHelper sharedPhysicsHelper] AddPolygonShapeToBody:_spaceShipBody : Points:3:self:_physicsParams];
    delete Points;
    
    _physicsParams = [[physicsParams alloc] init];
    [[PhysicsHelper sharedPhysicsHelper] AddEdgeShapeToBody:_spaceShipBody :CGPointMake(30,20):CGPointMake(50,30):self:_physicsParams];
    
    _physicsParams = [[physicsParams alloc] init];
    [[PhysicsHelper sharedPhysicsHelper] AddEdgeShapeToBody:_spaceShipBody :CGPointMake(30,-20):CGPointMake(50,-30):self:_physicsParams];
    
    
    [[PhysicsHelper sharedPhysicsHelper] setAngleOfBody:_spaceShipBody :_currentSpaceShipAngle];
}
@end
