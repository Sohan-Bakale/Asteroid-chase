//
//  SpaceShipConstants.h
//  Asteroid Chase
//
//  Created by Sohan on 3/7/13.
//  Copyright 2013 Sohan. All rights reserved.
//



typedef enum{
    DIRECTION_STABLE = 0,
    DIRECTION_CLOCKWISE,
    DIRECTION_ANTICLOCKWISE
}eRotationDirection;


#define SPACESHIP_VEL 7.0f
#define SPACESHIP_ANG_VEL 2.0f
#define BULLET_FIRE_INTERVAL 0.2f
