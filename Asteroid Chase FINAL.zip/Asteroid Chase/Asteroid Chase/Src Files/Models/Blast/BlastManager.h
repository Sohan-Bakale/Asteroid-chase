//
//  BlastManager.h
//  Asteroid Chase
//
//  Created by Sohan on 3/9/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "BlastConstants.h"
#import "GamePlayLayer.h"

@interface BlastManager : NSObject<BlastDelegate> {
    
    NSMutableArray * _blastParticlesArray;
}

+ (id) sharedBlastManager;

- (void) update : (ccTime) dt;

@end
