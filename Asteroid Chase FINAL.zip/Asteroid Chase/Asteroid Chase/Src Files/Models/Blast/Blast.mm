//
//  Blast.m
//  Asteroid Chase
//
//  Created by Sohan on 3/9/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import "Blast.h"


@implementation Blast

@synthesize destroyBlastParticle = _destroyBlastParticle;

- (id) initWithPos:(CGPoint)blastPos{

    if(self = [super init])
    {
        self.destroyBlastParticle = NO;
        _blastPos = blastPos;
        _blastParticleLife = RANDOM_NUMBER_IN_RANGE(MIN_LIFE_OF_BLAST_PARTICLE,MAX_LIFE_OF_BLAST_PARTICLE);
        _blastParticleLife  = _blastParticleLife * 0.1f;
        [self createBlastBody];
    }
    
    return self;
}

- (void) dealloc{
    
    [[PhysicsHelper sharedPhysicsHelper] destroyBody:_blastBody];
    [super dealloc];
}

- (void) createBlastBody{
    _blastBody = [[PhysicsHelper sharedPhysicsHelper] createBody:_blastPos :BODY_TYPE_DYNAMIC];
    
    physicsParams * _physicsParams = [[physicsParams alloc] init];
    _physicsParams.isSensor = YES;
    
    [[PhysicsHelper sharedPhysicsHelper] AddCircleShapeToBody:_blastBody :0.2f:CGPointZero:self:_physicsParams];
    
    float _motionangle = RANDOM_NUMBER_IN_RANGE(MIN_ANGLE_OF_MOTION_BLAST_PARTICLE,MAX_ANGLE_OF_MOTION_BLAST_PARTICLE);
    float _blastParticleSpeed = RANDOM_NUMBER_IN_RANGE(MIN_SPEED_OF_BLAST_PARTICLE,MAX_SPEED_OF_BLAST_PARTICLE);

    [[PhysicsHelper sharedPhysicsHelper] setLinearVelocityOfBody:_blastBody :CGPointMake(_blastParticleSpeed * cos(_motionangle), _blastParticleSpeed * sin(_motionangle))];
    
}

- (void) update : (ccTime) dt{
    
    _blastParticleLife-=dt;
    
    if(_blastParticleLife<=0)
        self.destroyBlastParticle = YES;
    
    
}


@end
