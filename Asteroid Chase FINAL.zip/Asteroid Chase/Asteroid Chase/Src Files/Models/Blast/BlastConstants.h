//
//  BlastConstants.h
//  Asteroid Chase
//
//  Created by Sohan on 3/9/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import <Foundation/Foundation.h>

#define NUM_OF_BLAST_PARTICLES 10
#define MIN_LIFE_OF_BLAST_PARTICLE 1
#define MAX_LIFE_OF_BLAST_PARTICLE 5
#define MIN_SPEED_OF_BLAST_PARTICLE 1
#define MAX_SPEED_OF_BLAST_PARTICLE 5
#define MIN_ANGLE_OF_MOTION_BLAST_PARTICLE 10
#define MAX_ANGLE_OF_MOTION_BLAST_PARTICLE 350