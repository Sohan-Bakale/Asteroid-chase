//
//  BlastManager.m
//  Asteroid Chase
//
//  Created by Sohan on 3/9/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import "BlastManager.h"
#import "Blast.h"


@implementation BlastManager

BlastManager *_blastManager = NULL;


+ (id) sharedBlastManager{
    
    if(_blastManager == NULL){
        return (_blastManager=[[self alloc] init]);
    }
    
    return _blastManager;
}

- (id) init{
    
    if(self = [super init]){
        _blastParticlesArray = [[NSMutableArray alloc] init];
    }
    
    return self;
}

- (void) dealloc{
    
    if(_blastParticlesArray){
        [_blastParticlesArray removeAllObjects];
        [_blastParticlesArray release];
        _blastParticlesArray = NULL;
    }
    
    _blastManager = NULL;
    [super dealloc];
}

- (void) createBlast:(CGPoint)blastPos{
    
    for(int i=0;i<NUM_OF_BLAST_PARTICLES;i++)
    {
    Blast * _blast = [[Blast alloc] initWithPos:blastPos];
    [_blastParticlesArray addObject:_blast];
    [_blast release];
    }
}

- (void) update : (ccTime) dt{
    
    for (int i=0;i<[_blastParticlesArray count];i++) {
        
        Blast * _blast = [_blastParticlesArray objectAtIndex:i];
        
        [_blast update:dt];
        
        
        if(_blast.destroyBlastParticle){
            [_blastParticlesArray removeObject:_blast];
            --i;
            continue;
        }
    }

}


@end
