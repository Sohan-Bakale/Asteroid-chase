//
//  Blast.h
//  Asteroid Chase
//
//  Created by Sohan on 3/9/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "BlastManager.h"

@interface Blast : NSObject {
    PhysicsBody *_blastBody;
    CGPoint _blastPos;
    BOOL _destroyBlastParticle;
    float _blastParticleLife;
}

- (id) initWithPos:(CGPoint)blastPos;
- (void) createBlastBody;

- (void) update : (ccTime) dt;

@property BOOL destroyBlastParticle;

@end
