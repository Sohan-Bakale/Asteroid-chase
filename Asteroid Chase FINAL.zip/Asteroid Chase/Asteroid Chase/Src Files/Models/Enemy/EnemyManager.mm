//
//  EnemyManager.m
//  Asteroid Chase
//
//  Created by Sohan on 3/9/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import "EnemyManager.h"
#import "Enemy.h"


@implementation EnemyManager

@synthesize gamePlayLayer=_gamePlayLayer;


EnemyManager *_enemyManager = NULL;

+ (id) sharedEnemyManager{
    
    if(_enemyManager == NULL){
        return (_enemyManager=[[self alloc] init]);
    }
    
    return _enemyManager;
}

- (id) init{
    
    if(self = [super init]){
        _enemyArray = [[NSMutableArray alloc] init];
    }
    
    return self;
}

- (void) dealloc{
    
    if(_enemyArray){
        [_enemyArray removeAllObjects];
        [_enemyArray release];
        _enemyArray = NULL;
    }
    
    _enemyManager = NULL;
    [super dealloc];
}

- (void)CreateEnemy:(EnemyParams*)enemyParams:(eEnemyType)enemyType{
    
    Enemy * _enemy = [[Enemy alloc] initWithParams:enemyParams:enemyType];
    [_enemyArray addObject:_enemy];
    [_enemy release];
    
}

- (void) setFireDelegate:(id<fireBulletDelegate>)firedelegate{
    _fireDelegate = firedelegate;
}

- (void) setBlastDelegate:(id<BlastDelegate>)blastdelegate{
    _blastDelegate = blastdelegate;
}


- (void) update : (ccTime) dt{
    
    for (int i=0;i<[_enemyArray count];i++) {
        
        Enemy * _enemy = [_enemyArray objectAtIndex:i];
        
        [_enemy update:dt];
        
        
        if(_enemy.destroyEnemy){
                       
            if(_enemy.enemyType == ENEMY_TYPE_ASTROID){
                [self breakEnemy:_enemy];
            }
            
            [_enemyArray removeObject:_enemy];
            --i;
            
            if([_enemyArray count] == 0){
                [_gamePlayLayer scheduleOnce:@selector(onLevelComplete) delay:1.0f];
            }
                
            
            continue;
        }
    }
    
}

- (void) onObstacleHit:(Enemy*)enemy{
    enemy.destroyEnemy = TRUE;

    [_gamePlayLayer addScore:enemy.enemyParams.pointsValue];
}

- (void) onSpaceShipHit:(Enemy*)enemy{
    
    enemy.destroyEnemy = TRUE;
}

- (void) breakEnemy:(Enemy*)enemy{
    
    EnemyParams *enemyParams = [[enemy.enemyParams copy] autorelease];
    eEnemyType enemyType = enemy.enemyType;
    CGPoint enemyPos = enemy.enemyPos;

    if(enemyParams.enemyScale <= 0.25f){
        
        [_blastDelegate createBlast:enemyPos];
        return;
    }
    else{
        
        EnemyParams *enemyParams1 = [[EnemyParams alloc] init];
        enemyParams1.enemyPosition = enemyPos;
        enemyParams1.shapeNumber = enemyParams.shapeNumber;
        enemyParams1.enemyScale=enemyParams.enemyScale * 0.5f;
        enemyParams1.enemySpeed = RANDOM_NUMBER_IN_RANGE(1, 5);
        enemyParams1.enemyAngle = RANDOM_NUMBER_IN_RANGE(LOWER_ANGLE_RANGE,HIGHER_ANGLE_RANGE);
        
        [self CreateEnemy:enemyParams1:enemyType];
        
        EnemyParams *enemyParams2 = [[EnemyParams alloc] init];
        enemyParams2.enemyPosition = enemyPos;
        enemyParams2.shapeNumber = enemyParams.shapeNumber;
        enemyParams2.enemyScale=enemyParams.enemyScale * 0.5f;
        enemyParams2.enemySpeed = RANDOM_NUMBER_IN_RANGE(1, 5);
        enemyParams2.enemyAngle = RANDOM_NUMBER_IN_RANGE(LOWER_ANGLE_RANGE,HIGHER_ANGLE_RANGE);
        [self CreateEnemy:enemyParams2:enemyType];
    }
}



@end
