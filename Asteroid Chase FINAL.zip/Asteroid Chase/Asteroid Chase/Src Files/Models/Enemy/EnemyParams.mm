//
//  EnemyParams.m
//  Asteroid Chase
//
//  Created by Sohan on 3/9/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import "EnemyParams.h"


@implementation EnemyParams

@synthesize  enemyPosition = _enemyPosition;
@synthesize  enemyAngle = _enemyAngle;
@synthesize  enemySpeed = _enemySpeed;
@synthesize enemyScale = _enemyScale;
@synthesize shapeNumber = _shapeNumber;
@synthesize pointsValue = _pointsValue;

- (id) init{
    if(self = [super init]){
        self.enemyPosition = CGPointZero;
        self.enemyAngle = 0.0f;
        self.enemySpeed = 5.0f;
        self.enemyScale = 1.0f;
        self.pointsValue = 30;
        self.shapeNumber = 0;
    }
    
    return self;
}

- (vector<CGPoint>*) getshapeForAstroid{
    
    switch (_shapeNumber) {
        case 0:
        {
            _pointsVector.push_back(CGPointMake(-20,50));
            _pointsVector.push_back(CGPointMake(20,50));
            _pointsVector.push_back(CGPointMake(25,35));
            _pointsVector.push_back(CGPointMake(50,20));
            _pointsVector.push_back(CGPointMake(50,-20));
            _pointsVector.push_back(CGPointMake(20,-23));
            _pointsVector.push_back(CGPointMake(20,-50));
            _pointsVector.push_back(CGPointMake(-20,-50));
            _pointsVector.push_back(CGPointMake(-10,-30));
            _pointsVector.push_back(CGPointMake(-50,-20));
            _pointsVector.push_back(CGPointMake(-50,20));
            _pointsVector.push_back(CGPointMake(-20,30));

        }
            break;
            
        case 1:
        {
            _pointsVector.push_back(CGPointMake(-30,40));
            _pointsVector.push_back(CGPointMake(15,50));
            _pointsVector.push_back(CGPointMake(25,25));
            _pointsVector.push_back(CGPointMake(40,30));
            _pointsVector.push_back(CGPointMake(30,-20));
            _pointsVector.push_back(CGPointMake(20,-23));
            _pointsVector.push_back(CGPointMake(20,-50));
            _pointsVector.push_back(CGPointMake(-10,-20));
            _pointsVector.push_back(CGPointMake(-20,-35));
            _pointsVector.push_back(CGPointMake(-50,-10));
            _pointsVector.push_back(CGPointMake(-30,30));
            _pointsVector.push_back(CGPointMake(-10,20));
        }
            break;
            
        case 2:
        {
            _pointsVector.push_back(CGPointMake(-10,20));
            _pointsVector.push_back(CGPointMake(25,50));
            _pointsVector.push_back(CGPointMake(25,25));
            _pointsVector.push_back(CGPointMake(40,30));
            _pointsVector.push_back(CGPointMake(30,-10));
            _pointsVector.push_back(CGPointMake(20,-23));
            _pointsVector.push_back(CGPointMake(20,-50));
            _pointsVector.push_back(CGPointMake(-10,-40));
            _pointsVector.push_back(CGPointMake(-20,-35));
            _pointsVector.push_back(CGPointMake(-50,-10));
            _pointsVector.push_back(CGPointMake(-30,30));
            _pointsVector.push_back(CGPointMake(-10,20));

        }
            break;

            
        case 3:
        {
            _pointsVector.push_back(CGPointMake(-30,40));
            _pointsVector.push_back(CGPointMake(15,30));
            _pointsVector.push_back(CGPointMake(35,45));
            _pointsVector.push_back(CGPointMake(20,10));
            _pointsVector.push_back(CGPointMake(40,-15));
            _pointsVector.push_back(CGPointMake(15,-33));
            _pointsVector.push_back(CGPointMake(25,-40));
            _pointsVector.push_back(CGPointMake(-15,-45));
            _pointsVector.push_back(CGPointMake(-25,-25));
            _pointsVector.push_back(CGPointMake(-50,-10));
            _pointsVector.push_back(CGPointMake(-40,40));

        }
            break;

            
            
        default:
        {
        }
            break;
    }
    
    return &_pointsVector;
}

- (id) copyWithZone:(NSZone *)zone{
    
    EnemyParams *newCopy = [[EnemyParams allocWithZone:zone] init];
    
    newCopy.enemyPosition = self.enemyPosition;
    newCopy.enemyAngle = self.enemyAngle;
    newCopy.enemySpeed = self.enemySpeed;
    newCopy.enemyScale = self.enemyScale;
    newCopy.shapeNumber = self.shapeNumber;

    return newCopy;
}


- (void) dealloc{
    
    [super dealloc];
}


@end
