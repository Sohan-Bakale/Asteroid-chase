//
//  Enemy.m
//  Asteroid Chase
//
//  Created by Sohan on 3/9/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import "Enemy.h"


@implementation Enemy

@synthesize destroyEnemy = _destroyEnemy;
@synthesize enemyParams = _enemyParams;
@synthesize enemyType = _enemyType;
@synthesize enemyPos = _enemyPos;

- (id)initWithParams:(EnemyParams*)enemyParams:(eEnemyType)enemyType{
    
    if(self = [super init]){
        _enemyBody = NULL;
        self.destroyEnemy = NO;
        self.enemyType = enemyType;

        _enemyParams = enemyParams;
        
        [self createEnemy];
    }
    
    return self;
}


-(void) dealloc{
    
    [[PhysicsHelper sharedPhysicsHelper] destroyBody:_enemyBody];
    [_enemyParams release];
    _enemyParams = NULL;
    [super dealloc];
}

- (void)createEnemy{
    
    if(_enemyType == ENEMY_TYPE_ASTROID){
        
        vector<CGPoint>* astroidShapeVector = [_enemyParams getshapeForAstroid];
        
       _enemyBody = [[PhysicsHelper sharedPhysicsHelper] createBody:_enemyParams.enemyPosition:BODY_TYPE_DYNAMIC];
        
        for(int i=0;i<astroidShapeVector->size();i++){
            
            int currentIndex = i;
            int nextIndex = (currentIndex==astroidShapeVector->size()-1)?0:currentIndex+1;
            
            physicsParams *_physicsParams = [[physicsParams alloc] init];
            
            CGPoint edgeVertexStartPos = astroidShapeVector->at(currentIndex);
            CGPoint edgeVertexEndPos = astroidShapeVector->at(nextIndex);
            
            edgeVertexStartPos = ccpMult(edgeVertexStartPos, _enemyParams.enemyScale);
            edgeVertexEndPos = ccpMult(edgeVertexEndPos, _enemyParams.enemyScale);

            
            [[PhysicsHelper sharedPhysicsHelper] AddEdgeShapeToBody:_enemyBody :edgeVertexStartPos:edgeVertexEndPos :self:_physicsParams];
            
        }
    }
    
    
    
    if(_enemyType == ENEMY_TYPE_SAUCER){
        
        
    }
    
    float enemySpeed = _enemyParams.enemySpeed;
    float enemyAngle = _enemyParams.enemyAngle;

    
    [[PhysicsHelper sharedPhysicsHelper] setLinearVelocityOfBody:_enemyBody :CGPointMake(-enemySpeed*cos(enemyAngle),-enemySpeed*sin(enemyAngle))];

    
}

- (void) update : (ccTime) dt{
    
    _enemyPos=[[PhysicsHelper sharedPhysicsHelper] getPositionOfBody:_enemyBody];
    

    BoundingBox  boundingBox = [[PhysicsHelper sharedPhysicsHelper] getBoundingBoxOfBody:_enemyBody];
    
    CGPoint lowerBound = boundingBox.lowerBound;
    CGPoint upperBound = boundingBox.upperBound;
        

    if(lowerBound.x < 0 && upperBound.x < 0){
        [[PhysicsHelper sharedPhysicsHelper] setPositionOfBody:_enemyBody :CGPointMake(SCREEN_WIDTH + _enemyPos.x - lowerBound.x,_enemyPos.y)];
    }
    
    if(lowerBound.x > SCREEN_WIDTH  && upperBound.x >SCREEN_WIDTH){
        [[PhysicsHelper sharedPhysicsHelper] setPositionOfBody:_enemyBody :CGPointMake( _enemyPos.x - upperBound.x,_enemyPos.y)];
    }
    
    if(lowerBound.y < 0 && upperBound.y <0){
        [[PhysicsHelper sharedPhysicsHelper] setPositionOfBody:_enemyBody :CGPointMake(_enemyPos.x, SCREEN_HEIGHT + _enemyPos.y - lowerBound.y)];
    }
    
    if(lowerBound.y > SCREEN_HEIGHT && upperBound.y >SCREEN_HEIGHT){
        [[PhysicsHelper sharedPhysicsHelper] setPositionOfBody:_enemyBody :CGPointMake(_enemyPos.x,_enemyPos.y - upperBound.y)];
    }
    
  
    
}


@end
