//
//  Enemy.h
//  Asteroid Chase
//
//  Created by Sohan on 3/9/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "EnemyManager.h"

@interface Enemy : NSObject {
    
    PhysicsBody * _enemyBody;
    BOOL _destroyEnemy;
    eEnemyType _enemyType;
    CGPoint _enemyPos;
    
    EnemyParams *_enemyParams;
}

@property BOOL destroyEnemy;
@property (assign) EnemyParams *enemyParams;
@property eEnemyType enemyType;
@property CGPoint enemyPos;

- (id)initWithParams:(EnemyParams*)enemyParams:(eEnemyType)enemyType;
- (void) update : (ccTime) dt;
- (void) createEnemy;

@end
