//
//  EnemyManager.h
//  Asteroid Chase
//
//  Created by Sohan on 3/9/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "GamePlayLayer.h"
#import "EnemyParams.h"


#define MIN_OFF_FROM_SHIP 150
#define LOWER_ANGLE_RANGE 20
#define HIGHER_ANGLE_RANGE 340
#define NUM_OF_AVAILABLE_SHAPES 4

typedef enum{
    ENEMY_TYPE_ASTROID = 0,
    ENEMY_TYPE_SAUCER,
    ENEMY_TYPE_SHIELD,
}eEnemyType;

@class Enemy;

@interface EnemyManager : NSObject{
    GamePlayLayer * _gamePlayLayer;
    NSMutableArray * _enemyArray;
    
    id<fireBulletDelegate> _fireDelegate;
    id<BlastDelegate> _blastDelegate;
}

@property (nonatomic,assign) GamePlayLayer *gamePlayLayer;


+ (id) sharedEnemyManager;
- (void) setFireDelegate:(id<fireBulletDelegate>)firedelegate;
- (void) setBlastDelegate:(id<BlastDelegate>)blastdelegate;
- (void)CreateEnemy:(EnemyParams*)enemyParams:(eEnemyType)enemyType;
- (void) update : (ccTime) dt;
- (void) onObstacleHit:(Enemy*)enemy;
- (void) onSpaceShipHit:(Enemy*)enemy;
- (void) breakEnemy:(Enemy*)enemy;

@end
