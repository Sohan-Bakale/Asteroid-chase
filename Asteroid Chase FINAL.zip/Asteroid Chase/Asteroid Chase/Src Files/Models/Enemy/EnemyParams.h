//
//  EnemyParams.h
//  Asteroid Chase
//
//  Created by Sohan on 3/9/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#include "vector.h"





@interface EnemyParams : NSObject<NSCopying> {
    
    CGPoint _enemyPosition;
    float _enemyAngle;
    float _enemySpeed;
    float _enemyScale;
    float _pointsValue;
    int _shapeNumber;
    int _numOfShapes;
    
    vector<CGPoint> _pointsVector;
}

- (vector<CGPoint>*) getshapeForAstroid;

@property CGPoint enemyPosition;
@property float enemyAngle;
@property float enemySpeed;
@property float enemyScale;
@property float pointsValue;
@property int shapeNumber;

@end
