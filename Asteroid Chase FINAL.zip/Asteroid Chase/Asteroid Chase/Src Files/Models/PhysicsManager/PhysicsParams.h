//
//  PhysicsParams.h
//  Asteroid Chase
//
//  Created by Sohan on 3/9/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"



#define BODY_TYPE_DYNAMIC b2_dynamicBody
#define BODY_TYPE_STATIC b2_staticBody
#define BODY_TYPE_KINEMATIC b2_kinematicBody


typedef struct{
    
    CGPoint lowerBound;
    CGPoint upperBound;
    
}BoundingBox;

@interface physicsParams : NSObject{
    float _density;
    float _friction;
    float _restitution;
    int _groupIndex;
    BOOL _isSensor;
    uint _maskBits;
    uint _categoryBits;
}

@property float density;
@property float friction;
@property float restitution;
@property int groupIndex;
@property BOOL isSensor;
@property uint maskBits;
@property uint categoryBits;

@end
