//
//  PhysicsHelper.m
//  Asteroid Chase
//
//  Created by Sohan on 3/5/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import "PhysicsHelper.h"
#import "ContactListener.h"

@implementation PhysicsBody

@synthesize physicsBody = _physicsBody;

- (id) init{
    
    if(self = [super init]){
    
        self.physicsBody = NULL;
    }
    
    return self;
}

- (void) dealloc{
    
    self.physicsBody = NULL;
    [super dealloc];
}


@end

@implementation PhysicsHelper

PhysicsHelper *_physicsHelper = NULL;


+ (id) sharedPhysicsHelper{
    
    if(_physicsHelper == NULL)
	{
		_physicsHelper = [[PhysicsHelper alloc]init];
		[_physicsHelper initWorld];
	}
	return _physicsHelper;

}
- (void) initWorld{
    
    bool doSleep = true;
	_world = new b2World(GRAVITY);
    _world->SetAllowSleeping(doSleep);
	_world->SetContinuousPhysics(false);
    
	MyContactListener* _contactListener = new MyContactListener;
	_world->SetContactListener(_contactListener);
    
    
	// Debug Draw functions
	_debugDraw = new GLESDebugDraw(PTM_RATIO);
	_world->SetDebugDraw(_debugDraw);
	
	uint32 flags = 0;
	flags += b2Draw::e_shapeBit;
	//		flags += b2DebugDraw::e_jointBit;
	//		flags += b2Draw::e_aabbBit;
	//		flags += b2DebugDraw::e_pairBit;
	//		flags += b2DebugDraw::e_centerOfMassBit;
	_debugDraw->SetFlags(flags);

}

- (void) onRenderFrame{
    _world->DrawDebugData();
}

- (void) onUpdateFrame:(float)deltaTime{
    
    //It is recommended that a fixed time step is used with Box2D for stability
	//of the simulation, however, we are using a variable time step here.
	//You need to make an informed choice, the following URL is useful
	//http://gafferongames.com/game-physics/fix-your-timestep/
	
	int32 velocityIterations = 3;
	int32 positionIterations = 1;
	
	// Instruct the world to perform a single step of simulation. It is
	// generally best to keep the time step and iterations fixed.
	_world->Step(deltaTime, velocityIterations, positionIterations);

}

- (b2World*) getWorld{
    return _world;
}

- (void) setFixtureParams:(b2Fixture*)fix:(physicsParams*)physicsParams{
    
    fix->SetDensity(physicsParams.density);
    fix->SetRestitution(physicsParams.restitution);
    fix->SetFriction(physicsParams.friction);
    fix->SetSensor(physicsParams.isSensor);
    
    b2Filter filter = fix->GetFilterData();
    
    if(physicsParams.maskBits)
    filter.maskBits = physicsParams.maskBits;
    
    if(physicsParams.categoryBits)
    filter.categoryBits = physicsParams.categoryBits;
    
    fix->SetFilterData(filter);
    
    [physicsParams release];
    physicsParams = NULL;


}

- (PhysicsBody*) createBody:(CGPoint)pos:(b2BodyType)type{
    
    PhysicsBody *_physicsBody = [[PhysicsBody alloc] init];
    
    b2BodyDef bodyDef;
	bodyDef.type = type;
    bodyDef.position.Set(PIXELS_TO_METERS(pos.x,pos.y));
	bodyDef.allowSleep = false;
    _physicsBody.physicsBody = _world->CreateBody(&bodyDef);
    
    _physicsBody.physicsBody->SetBullet(true);

    return _physicsBody;
}

- (void) AddEdgeShapeToBody:(PhysicsBody*)body:(CGPoint)startPoint:(CGPoint)endPoint:(void*)data:(physicsParams*)physicsParams{

    if(!body)
        return;
    
    b2EdgeShape shape;
    shape.Set(b2Vec2(PIXELS_TO_METERS(startPoint.x,startPoint.y)), b2Vec2(PIXELS_TO_METERS(endPoint.x,endPoint.y)));
    
    
    b2FixtureDef fixtureDef;
    fixtureDef.shape = &shape;
    fixtureDef.userData = data;
    
    b2Fixture * fix = body.physicsBody->CreateFixture(&fixtureDef);
    
    [self setFixtureParams:fix :physicsParams];
}


- (void) AddBoxShapeToBody:(PhysicsBody*)body:(float)width:(float)height:(CGPoint)center:(float)angle:(void*)data:(physicsParams*)physicsParams{
    
    if(!body)
        return;

    
    b2PolygonShape shape;
    shape.SetAsBox(width/PTM_RATIO,height/PTM_RATIO,b2Vec2(PIXELS_TO_METERS(center.x,center.y)),angle);
    
    b2FixtureDef fixtureDef;
    fixtureDef.shape = &shape;
    fixtureDef.userData = data;
    
    b2Fixture * fix = body.physicsBody->CreateFixture(&fixtureDef);
    
    [self setFixtureParams:fix :physicsParams];
}


- (void) AddCircleShapeToBody:(PhysicsBody*)body:(float)radius:(CGPoint)center:(void*)data:(physicsParams*)physicsParams{
    
    if(!body)
        return;

    b2CircleShape shape;
    shape.m_radius = radius/PTM_RATIO;
    shape.m_p = b2Vec2(PIXELS_TO_METERS(center.x,center.y));
    
    b2FixtureDef fixtureDef;
    fixtureDef.shape = &shape;
    fixtureDef.userData = data;
    
    b2Fixture * fix = body.physicsBody->CreateFixture(&fixtureDef);
    
    [self setFixtureParams:fix :physicsParams];
}



- (void) AddPolygonShapeToBody:(PhysicsBody*)body:(CGPoint*)vertices:(int)numOfVertices:(void*)data:(physicsParams*)physicsParams{
    
    if(!body)
        return;
    
    b2PolygonShape shape;
    
    b2Vec2 * polygonVertices = new b2Vec2[numOfVertices];
    
    for(int i=0;i<numOfVertices;i++)
        polygonVertices[i]=b2Vec2(PIXELS_TO_METERS(vertices[i].x,vertices[i].y));
    
    shape.Set(polygonVertices,numOfVertices);
        
    b2FixtureDef fixtureDef;
    fixtureDef.shape = &shape;
    fixtureDef.userData = data;
    
    b2Fixture * fix = body.physicsBody->CreateFixture(&fixtureDef);
    
    [self setFixtureParams:fix :physicsParams];
    delete polygonVertices;
}

-(CGPoint) getPositionOfBody:(PhysicsBody*)body{
    
    b2Vec2 pos = body.physicsBody->GetPosition();
    return CGPointMake(METERS_TO_PIXELS(pos.x, pos.y));
}

- (void) setPositionOfBody:(PhysicsBody*)body:(CGPoint)pos{
    
    body.physicsBody->SetTransform(b2Vec2(PIXELS_TO_METERS(pos.x,pos.y)),body.physicsBody->GetAngle());
}

- (float) getAngleOfBody:(PhysicsBody*)body{
    return body.physicsBody->GetAngle();
}


- (void) setAngleOfBody:(PhysicsBody*)body:(float)angle{
    
    body.physicsBody->SetTransform(body.physicsBody->GetPosition(),angle);
}

- (void) setAngularVelocityOfBody:(PhysicsBody*)body:(float)angVel{
    body.physicsBody->SetAngularVelocity(angVel);
}

- (void) setLinearVelocityOfBody:(PhysicsBody*)body:(CGPoint)linVel{
    body.physicsBody->SetLinearVelocity(b2Vec2(linVel.x,linVel.y));
}

- (float) getAngularVelocityOfBody:(PhysicsBody*)body{
    return body.physicsBody->GetAngularVelocity();
}

- (CGPoint) getLinearVelocityOfBody:(PhysicsBody*)body{
    b2Vec2 vel = body.physicsBody->GetLinearVelocity();
    
    return CGPointMake(vel.x,vel.y);
}

- (BoundingBox)getBoundingBoxOfBody:(PhysicsBody*)body{
  
    
    b2AABB aabb;
    
    aabb.lowerBound = b2Vec2(FLT_MAX,FLT_MAX);
    aabb.upperBound = b2Vec2(-FLT_MAX,-FLT_MAX);
    
    b2Fixture *fix = body.physicsBody->GetFixtureList();
    
    while (fix != NULL)
    {
        aabb.Combine(aabb, fix->GetAABB(0));
        fix = fix->GetNext();
    }
    
    BoundingBox  boundingBox;
    
    boundingBox.lowerBound = CGPointMake(METERS_TO_PIXELS(aabb.lowerBound.x, aabb.lowerBound.y));
    boundingBox.upperBound = CGPointMake(METERS_TO_PIXELS(aabb.upperBound.x, aabb.upperBound.y));
    
    return boundingBox;
}

- (BOOL) isObstacleSurrounding:(float)boundsoffset:(CGPoint)point{
    
    CGRect bounds = CGRectMake(point.x - boundsoffset, point.y - boundsoffset, boundsoffset*2, boundsoffset*2);
    
    
    
    for(b2Body  *body = _world->GetBodyList();body;body = body->GetNext()){
        
        if(CGRectContainsPoint(bounds,CGPointMake(METERS_TO_PIXELS(body->GetPosition().x, body->GetPosition().y))))
            return TRUE;
    }
    
    return FALSE;
    
}

- (void) destroyBody:(PhysicsBody*)body{
    
    if(!body)
        return;
    
    _world->DestroyBody(body.physicsBody);
    [body release];
    body = NULL;
}
@end











