//
//  ContactListener.h
//  Asteroid Chase
//
//  Created by Sohan on 3/9/13.
//  Copyright 2013 Sohan. All rights reserved.
//


#import <vector>

#import "GamePlayLayer.h"

struct MyContact
{
    b2Fixture *fixtureA;
    b2Fixture *fixtureB;
    bool operator==(const MyContact& other) const
    {
        return (fixtureA == other.fixtureA) && (fixtureB == other.fixtureB);
    }
    };
    
    class MyContactListener : public b2ContactListener
    {
        
    public:
        MyContactListener();
        ~MyContactListener();
        
        virtual void BeginContact(b2Contact* contact);
        virtual void EndContact(b2Contact* contact);
        virtual void PreSolve(b2Contact* contact, const b2Manifold* oldManifold);
        virtual void PostSolve(b2Contact* contact, const b2ContactImpulse* impulse);
        
        void setScene(id scene);
        
    private:   
        std::vector<MyContact>_contacts;
        id m_scene;
    };
