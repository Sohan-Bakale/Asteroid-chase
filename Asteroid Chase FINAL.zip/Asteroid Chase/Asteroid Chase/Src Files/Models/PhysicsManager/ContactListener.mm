//
//  ContactListener.m
//  Asteroid Chase
//
//  Created by Sohan on 3/9/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import "ContactListener.h"
#import "Enemy.h"
#import "Bullet.h"
#import "SpaceShip.h"

MyContactListener::MyContactListener() : m_scene(nil)
{
}

MyContactListener::~MyContactListener()
{
}

void MyContactListener::BeginContact(b2Contact* contact)
{
// We need to copy out the data because the b2Contact passed in
// is reused.

	b2Fixture* fixA = contact->GetFixtureA();
	b2Fixture* fixB = contact->GetFixtureB();

	

	id UserDataA = (id)fixA->GetUserData();
	id UserDataB = (id)fixB->GetUserData();

    Enemy * enemy = NULL;
    Bullet * bullet = NULL;
    SpaceShip * spaceShip = NULL;

	if ([UserDataA isKindOfClass:[Enemy class]])
		enemy = (Enemy*)UserDataA;
   else
	if ([UserDataB isKindOfClass:[Enemy class]])
		enemy = (Enemy*)UserDataB;
    

	if ([UserDataA isKindOfClass:[Bullet class]])
		bullet = (Bullet*)UserDataA;
    else
        if ([UserDataB isKindOfClass:[Bullet class]])
            bullet = (Bullet*)UserDataB;
    
    
    if ([UserDataA isKindOfClass:[SpaceShip class]])
		spaceShip = (SpaceShip*)UserDataA;
    else
        if ([UserDataB isKindOfClass:[SpaceShip class]])
            spaceShip = (SpaceShip*)UserDataB;
    
  
    if(bullet && enemy){
        
        [[EnemyManager sharedEnemyManager] onObstacleHit:enemy];
        bullet.destroyBullet = TRUE;
    }
    
    if(spaceShip && enemy){
        [[EnemyManager sharedEnemyManager] onSpaceShipHit:enemy];
        [[SpaceShip sharedSpaceShip] setToDestroySpaceShip:YES];
    }
    
    if(spaceShip && bullet){
        [[SpaceShip sharedSpaceShip] setToDestroySpaceShip:YES];
        bullet.destroyBullet = TRUE;
    }

    
    MyContact myContact = {fixA , fixB };
    _contacts.push_back(myContact);
}

void MyContactListener::EndContact(b2Contact* contact)
{
 
}

void MyContactListener::PreSolve(b2Contact* contact, const b2Manifold* oldManifold)
{
}

void MyContactListener::PostSolve(b2Contact* contact, const b2ContactImpulse* impulse)
{
    b2Fixture* fixA = contact->GetFixtureA();
	b2Fixture* fixB = contact->GetFixtureB();
    
	
    
	id UserDataA = (id)fixA->GetUserData();
	id UserDataB = (id)fixB->GetUserData();
    
    Enemy * enemy = NULL;
    Bullet * bullet = NULL;
    SpaceShip * spaceShip = NULL;
    
	if ([UserDataA isKindOfClass:[Enemy class]])
		enemy = (Enemy*)UserDataA;
    else
        if ([UserDataB isKindOfClass:[Enemy class]])
            enemy = (Enemy*)UserDataB;
    
    
	if ([UserDataA isKindOfClass:[Bullet class]])
		bullet = (Bullet*)UserDataA;
    else
        if ([UserDataB isKindOfClass:[Bullet class]])
            bullet = (Bullet*)UserDataB;
    
    
    


}
