//
//  PhysicsParams.m
//  Asteroid Chase
//
//  Created by Sohan on 3/9/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import "PhysicsParams.h"



@implementation physicsParams

@synthesize density = _density;
@synthesize friction = _friction;
@synthesize restitution = _restitution;
@synthesize groupIndex = _groupIndex;
@synthesize isSensor = _isSensor;
@synthesize maskBits = _maskBits;
@synthesize categoryBits = _categoryBits;

- (id) init{
    if(self = [super init]){
        self.density = 1.0f;
        self.friction = 1.0f;
        self.restitution = 1.0f;
        self.groupIndex = -1;
        self.isSensor = NO;
        self.maskBits = 0;
        self.categoryBits = 0;
    }
    
    return self;
}

- (void)dealloc{
    
    [super dealloc];
}

@end