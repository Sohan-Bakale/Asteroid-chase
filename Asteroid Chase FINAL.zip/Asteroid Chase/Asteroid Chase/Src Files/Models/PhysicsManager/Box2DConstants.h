//
//  Box2DConstants.h
//  Asteroid Chase
//
//  Created by Sohan on 3/6/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import <Foundation/Foundation.h>

#define PTM_RATIO 32.0f
#define GRAVITY b2Vec2(0.0f,0.0f)

#define PIXELS_TO_METERS(_X_,_Y_) _X_/PTM_RATIO,_Y_/PTM_RATIO
#define METERS_TO_PIXELS(_X_,_Y_) _X_*PTM_RATIO,_Y_*PTM_RATIO