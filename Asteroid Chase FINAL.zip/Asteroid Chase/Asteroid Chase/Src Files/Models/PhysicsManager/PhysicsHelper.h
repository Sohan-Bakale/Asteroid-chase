//
//  PhysicsHelper.h
//  Asteroid Chase
//
//  Created by Sohan on 3/5/13.
//  Copyright 2013 Sohan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "GLES-Render.h"
#import "PhysicsParams.h"
#import "Box2D.h"
#import "Box2DConstants.h"

@interface PhysicsBody : NSObject{
    b2Body * _physicsBody;
}

@property b2Body *physicsBody;

@end

@interface PhysicsHelper : NSObject {
    
    b2World*			_world;
	b2Vec2				_gravity;
	GLESDebugDraw*		_debugDraw;

}


+ (id) sharedPhysicsHelper;
- (void) initWorld;
- (void) onRenderFrame;
- (void) onUpdateFrame:(float)deltaTime;

- (b2World*) getWorld;

- (PhysicsBody*) createBody:(CGPoint)pos:(b2BodyType)type;
- (void) AddEdgeShapeToBody:(PhysicsBody*)body:(CGPoint)startPoint:(CGPoint)endPoint:(void*)data:(physicsParams*)physicsParams;
- (void) AddBoxShapeToBody:(PhysicsBody*)body:(float)width:(float)height:(CGPoint)center:(float)angle:(void*)data:(physicsParams*)physicsParams;
- (void) AddCircleShapeToBody:(PhysicsBody*)body:(float)radius:(CGPoint)center:(void*)data:(physicsParams*)physicsParams;
- (void) AddPolygonShapeToBody:(PhysicsBody*)body:(CGPoint*)vertices:(int)numOfVertices:(void*)data:(physicsParams*)physicsParams;

- (void) setFixtureParams:(b2Fixture*)fix:(physicsParams*)physicsParams;
- (CGPoint) getPositionOfBody:(PhysicsBody*)body;
- (void) setPositionOfBody:(PhysicsBody*)body:(CGPoint)pos;
- (float) getAngleOfBody:(PhysicsBody*)body;
- (void) setAngleOfBody:(PhysicsBody*)body:(float)angle;
- (void) setAngularVelocityOfBody:(PhysicsBody*)body:(float)angVel;
- (void) setLinearVelocityOfBody:(PhysicsBody*)body:(CGPoint)linVel;

- (float) getAngularVelocityOfBody:(PhysicsBody*)body;
- (CGPoint) getLinearVelocityOfBody:(PhysicsBody*)body;

- (BoundingBox)getBoundingBoxOfBody:(PhysicsBody*)body;

- (BOOL) isObstacleSurrounding:(float)boundsoffset:(CGPoint)point;

- (void) destroyBody:(PhysicsBody*)body;

@end



