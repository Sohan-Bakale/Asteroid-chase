

Gamelay - Aestroid chase is a basic strategy game to destroy Aestroids moving in space.

Tools:                  xcode version 4.5

Platform:               ios verion 6.x

Target Device:          iPad

Programming Language:   Objective C++

Physics Engine 		Box2D

Graphics Engine		Cocos2d,OpenGLES 